let browser = window.chrome || window.browser;


browser.webRequest.onBeforeRequest.addListener(
    function(details) {        
        let createData = {
          url: details.url.replace('.incognito.', ''),
          incognito: true,
        };
        browser.windows.create(createData);
        browser.tabs.remove(details.tabId);
    },
    {
      urls: [
        "https://domclick.ru.incognito./*",
        "https://qa.domclick.ru.incognito./*",
        "http://domclick.ru.incognito./*",
        "http://qa.domclick.ru.incognito./*",
      ],
    types: ["main_frame"],
    },
    ["blocking"]
);